//
//  User.swift
//  Cool Cars Project
//
//  Created by Dante Ausonio on 11/15/22.
//

import Foundation


struct User {
    var ownedVehicle: Vehicle!
    
}
